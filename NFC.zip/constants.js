var firebaseConfig = {
    apiKey: "AIzaSyAkQXsSCrt3uzoUjX_FMokg_ZL3bE4CoYA",
    authDomain: "olevels-live.firebaseapp.com",
    projectId: "olevels-live",
    storageBucket: "olevels-live.appspot.com",
    messagingSenderId: "39474177871",
    appId: "1:39474177871:web:8f220c929ec61638f8073a",
    measurementId: "G-6TJF0S5X3X",
  };
  
  if (!("NDEFReader" in window))
    ChromeSamples.setStatus("Web NFC is not available. Use Chrome on Android.");